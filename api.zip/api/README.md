 # MyDiary
     
     MyDiary is an online journal where users can pen down their thoughts and feelings.
GitHub Pages link: https://nyabongoedgar.github.io/MyDiary/
# Dependencies
    >Python 3.5
    >Flask 1.0.2

 # Main features
    >MyDiary lets new users sign up and sign in.
    >A user can make an entry into their diary.
    >A user can retrieve all his/her diary entries
    >A user can modify his/her diary entries
 
